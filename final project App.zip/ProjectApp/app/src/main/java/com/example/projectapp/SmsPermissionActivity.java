package com.example.projectapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int REQ_SMS = 42;

    private TextView textPermissionState;
    private Button buttonSendTest, buttonRequestSms, buttonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_permission);

        // Apply system bar insets to the root (id: sms)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.sms), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // Bind views (ids must match activity_sms_permission.xml)
        textPermissionState = findViewById(R.id.textPermissionState);
        buttonRequestSms    = findViewById(R.id.buttonRequestSms);
        buttonSendTest      = findViewById(R.id.buttonSendTest);
        buttonBack          = findViewById(R.id.buttonBack);

        // Request permission if missing (so testers see the prompt right away)
        ensurePermissionOrRequest();
        refreshUi();

        // Clicks
        buttonRequestSms.setOnClickListener(v -> {
            ensurePermissionOrRequest();
            refreshUi();
        });

        buttonSendTest.setOnClickListener(v -> sendTestSms());

        // EXPLICIT back: always return to WeightsActivity
        buttonBack.setOnClickListener(v -> navigateBackToWeights());
    }

    private void navigateBackToWeights() {
        Intent i = new Intent(SmsPermissionActivity.this, WeightsActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
        finish();
    }

    @Override
    public void onBackPressed() {
        // Make hardware/gesture back behave the same as the Back button
        navigateBackToWeights();
    }

    private void refreshUi() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        textPermissionState.setText(granted ? "Permission status: GRANTED" : "Permission status: NOT GRANTED");
        buttonSendTest.setEnabled(granted);
    }

    private void ensurePermissionOrRequest() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            return;
        }
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            Toast.makeText(this, "SMS permission is required to send alerts.", Toast.LENGTH_SHORT).show();
        }
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
    }

    private void sendTestSms() {
        try {
            // For emulator-to-emulator tests use the paired AVD number (e.g., 5556 if this device is 5554)
            SmsManager.getDefault().sendTextMessage("5556", null,
                    "Healthy Way: test SMS alert.", null, null);
            Toast.makeText(this, "Test SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SMS) {
            refreshUi();
        }
    }
}
