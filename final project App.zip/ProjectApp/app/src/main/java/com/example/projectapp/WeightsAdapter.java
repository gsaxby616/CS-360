package com.example.projectapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectapp.WeightEntry;

import java.util.ArrayList;
import java.util.List;

public class WeightsAdapter extends RecyclerView.Adapter<WeightsAdapter.VH> {

    public interface Listener {
        void onDelete(WeightEntry entry);
        void onEdit(WeightEntry entry);
    }

    private final Listener listener;
    private final List<WeightEntry> data = new ArrayList<>();

    public WeightsAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setData(List<WeightEntry> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        WeightEntry e = data.get(pos);
        h.textDate.setText(e.date);
        h.textWeight.setText(String.format("%.1f lb", e.pounds));
        h.buttonDelete.setOnClickListener(v -> listener.onDelete(e));
        h.itemView.setOnLongClickListener(v -> { listener.onEdit(e); return true; });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView textDate, textWeight;
        Button buttonDelete;
        VH(@NonNull View itemView) {
            super(itemView);
            textDate   = itemView.findViewById(R.id.textDate);
            textWeight = itemView.findViewById(R.id.textWeight);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
