package com.example.projectapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectapp.AppDatabase;
import com.example.projectapp.WeightEntry;

import java.util.List;
import java.util.concurrent.Executors;

public class WeightsActivity extends AppCompatActivity implements WeightsAdapter.Listener {

    private WeightsAdapter adapter;
    private EditText editTextDate, editTextWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_weights);

        // Root view id in activity_weights.xml is "weights"
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.weights), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // RecyclerView (grid)
        RecyclerView rv = findViewById(R.id.recyclerWeights);   // must match activity_weights.xml
        rv.setLayoutManager(new GridLayoutManager(this, 1));     // 1 column = table-like grid
        adapter = new WeightsAdapter(this);
        rv.setAdapter(adapter);

        // Inputs + Add button
        editTextDate   = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        Button buttonAdd = findViewById(R.id.buttonAdd);
        buttonAdd.setOnClickListener(v -> addEntry());

        // SMS permission screen button
        Button smsButton = findViewById(R.id.buttonSmsSettings);
        if (smsButton != null) {
            smsButton.setOnClickListener(v ->
                    startActivity(new Intent(this, SmsPermissionActivity.class))
            );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAll();
    }

    /** Read all items and display in the grid */
    private void loadAll() {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<WeightEntry> list = AppDatabase.get(this).weightDao().getAll();
            runOnUiThread(() -> adapter.setData(list));
        });
    }

    /** Create (Add) a new weight entry */
    private void addEntry() {
        final String date = editTextDate.getText().toString().trim();
        final String wStr = editTextWeight.getText().toString().trim();
        if (TextUtils.isEmpty(date) || TextUtils.isEmpty(wStr)) {
            Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show();
            return;
        }
        final double pounds;
        try {
            pounds = Double.parseDouble(wStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
            return;
        }

        Executors.newSingleThreadExecutor().execute(() -> {
            WeightEntry e = new WeightEntry();
            e.date = date;
            e.pounds = pounds;
            AppDatabase.get(this).weightDao().insert(e);

            runOnUiThread(() -> {
                editTextWeight.setText("");
                loadAll();


            });
        });
    }

    /** Delete an item (invoked from row 'Delete' button in adapter) */
    @Override
    public void onDelete(WeightEntry entry) {
        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase.get(this).weightDao().delete(entry);
            runOnUiThread(this::loadAll);
        });
    }


    @Override
    public void onEdit(WeightEntry entry) {
        entry.pounds = entry.pounds + 1.0;
        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase.get(this).weightDao().update(entry);
            runOnUiThread(this::loadAll);
        });
    }
}
