package com.example.projectapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "weights")
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    public long id;

    public String date;      // simple string
    public double pounds;    // weight value
}
