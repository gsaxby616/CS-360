package com.example.projectapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.projectapp.AppDatabase;
import com.example.projectapp.User;

import java.util.concurrent.Executors;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameOrEmail, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Root id in activity_login.xml is "login"
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        usernameOrEmail = findViewById(R.id.editTextTextEmailAddress);
        password        = findViewById(R.id.editTextTextPassword);
        Button btnLogin  = findViewById(R.id.buttonLogin);
        Button btnCreate = findViewById(R.id.buttonCreateAccount);

        btnCreate.setOnClickListener(v -> createAccount());
        btnLogin.setOnClickListener(v -> login());
    }

    private void createAccount() {
        final String u = usernameOrEmail.getText().toString().trim();
        final String p = password.getText().toString().trim();
        if (u.isEmpty() || p.isEmpty()) {
            Toast.makeText(this, "Enter username & password", Toast.LENGTH_SHORT).show();
            return;
        }
        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase db = AppDatabase.get(this);
            if (db.userDao().findByUsername(u) != null) {
                runOnUiThread(() -> Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show());
                return;
            }
            User user = new User();
            user.username = u;
            user.password = p;
            db.userDao().insert(user);
            runOnUiThread(() -> Toast.makeText(this, "Account created. You can log in now.", Toast.LENGTH_SHORT).show());
        });
    }

    private void login() {
        final String u = usernameOrEmail.getText().toString().trim();
        final String p = password.getText().toString().trim();
        if (u.isEmpty() || p.isEmpty()) {
            Toast.makeText(this, "Enter username & password", Toast.LENGTH_SHORT).show();
            return;
        }
        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase db = AppDatabase.get(this);
            User user = db.userDao().login(u, p);
            runOnUiThread(() -> {
                if (user == null) {
                    Toast.makeText(this, "Invalid login. Create an account first.", Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(new Intent(this, WeightsActivity.class));
                    finish();
                }
            });
        });
    }
}
