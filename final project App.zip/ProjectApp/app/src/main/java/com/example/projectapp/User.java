package com.example.projectapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Index;

@Entity(tableName = "users", indices = @Index(value = {"username"}, unique = true))
public class User {
    @PrimaryKey(autoGenerate = true)
    public long id;

    public String username;
    public String password;
}
