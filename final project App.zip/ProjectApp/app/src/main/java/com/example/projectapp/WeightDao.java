package com.example.projectapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeightDao {
    @Insert
    long insert(WeightEntry entry);

    @Update
    int update(WeightEntry entry);

    @Delete
    int delete(WeightEntry entry);

    @Query("SELECT * FROM weights ORDER BY date DESC")
    List<WeightEntry> getAll();
}
